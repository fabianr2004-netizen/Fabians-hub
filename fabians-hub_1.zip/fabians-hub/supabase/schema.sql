-- Fabian's Hub: database setup
-- Paste this whole file into Supabase > SQL Editor > New query, then press Run.

create extension if not exists pgcrypto;

-- Every website the hub manages
create table if not exists public.sites (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,              -- short name used by the website, e.g. 'precision'
  name text not null,
  pricing jsonb not null default '{}',    -- instant-quote prices the website reads
  alert_email text,                       -- extra people to alert for this site (e.g. the client)
  alert_phone text,
  created_at timestamptz not null default now()
);

-- People who can see everything (you)
create table if not exists public.admins (
  user_id uuid primary key references auth.users on delete cascade
);

-- Clients: which site(s) each login can see
create table if not exists public.members (
  user_id uuid references auth.users on delete cascade,
  site_id uuid references public.sites on delete cascade,
  primary key (user_id, site_id)
);

-- Every inquiry from every site
create table if not exists public.inquiries (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null references public.sites on delete cascade,
  type text not null default 'request',   -- 'instant' (priced quote) or 'request'
  status text not null default 'new' check (status in ('new','quoted','booked','closed')),
  name text, phone text, email text, vehicle text, service text,
  quote numeric,
  preferred_date text,
  details jsonb not null default '{}',    -- options picked, message, anything else
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists inquiries_site_created on public.inquiries (site_id, created_at desc);

-- Helpers
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from admins where user_id = auth.uid())
$$;

create or replace function public.can_access(s uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select is_admin() or exists (select 1 from members where user_id = auth.uid() and site_id = s)
$$;

-- The first person to log in to the hub becomes the admin (that's you). Nobody after.
create or replace function public.claim_admin() returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return false; end if;
  if not exists (select 1 from admins) then
    insert into admins (user_id) values (auth.uid());
  end if;
  return is_admin();
end $$;

create or replace function public.touch_updated() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
drop trigger if exists inquiries_touch on public.inquiries;
create trigger inquiries_touch before update on public.inquiries
  for each row execute function public.touch_updated();

-- Security: each login only sees what it should
alter table public.sites enable row level security;
alter table public.admins enable row level security;
alter table public.members enable row level security;
alter table public.inquiries enable row level security;

drop policy if exists sites_read on public.sites;
create policy sites_read on public.sites for select using (can_access(id));
drop policy if exists sites_write on public.sites;
create policy sites_write on public.sites for all using (is_admin()) with check (is_admin());
drop policy if exists sites_client_pricing on public.sites;
create policy sites_client_pricing on public.sites for update using (can_access(id)) with check (can_access(id));

drop policy if exists admins_read on public.admins;
create policy admins_read on public.admins for select using (user_id = auth.uid());

drop policy if exists members_read on public.members;
create policy members_read on public.members for select using (user_id = auth.uid() or is_admin());
drop policy if exists members_write on public.members;
create policy members_write on public.members for all using (is_admin()) with check (is_admin());

drop policy if exists inq_read on public.inquiries;
create policy inq_read on public.inquiries for select using (can_access(site_id));
drop policy if exists inq_update on public.inquiries;
create policy inq_update on public.inquiries for update using (can_access(site_id)) with check (can_access(site_id));
drop policy if exists inq_delete on public.inquiries;
create policy inq_delete on public.inquiries for delete using (is_admin());
-- (New inquiries come in through the hub's server, which bypasses these rules safely.)

-- Live updates in the hub when a new inquiry lands
do $$ begin
  alter publication supabase_realtime add table public.inquiries;
exception when others then null; end $$;

-- First site: Precision Collision & Customs, with the prices from the website
insert into public.sites (slug, name, pricing) values (
  'precision', 'Precision Collision & Customs',
  '{"tint":{"carbon":{"coupe":199,"sedan":229,"suv":259,"truck":239},
            "ceramic":{"coupe":299,"sedan":329,"suv":369,"truck":349},
            "frontsCarbon":99,"frontsCeramic":139,"strip":40,"windshield":199,"removal":75},
    "ambient":{"basic":349,"full":549,"premium":749},
    "starliner":{"s300":499,"s500":699,"s800":899,"shooting":150}}'
) on conflict (slug) do nothing;

insert into public.sites (slug, name) values
  ('top4', 'Top 4 Barber Supply'),
  ('tintsync', 'TintSync')
on conflict (slug) do nothing;
