// GET /api/config — gives the hub page its public Supabase settings (safe to share).
import { env } from './_lib.js';

export default function handler(req, res) {
  res.status(200).json({ supabaseUrl: env('SUPABASE_URL'), supabaseAnonKey: env('SUPABASE_ANON_KEY') });
}
