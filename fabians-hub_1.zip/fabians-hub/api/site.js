// GET /api/site?slug=precision — websites read their live prices here.
import { cors, getSite } from './_lib.js';

export default async function handler(req, res) {
  if (cors(req, res)) return;
  try {
    const site = await getSite(String(req.query.slug || ''));
    if (!site) return res.status(404).json({ error: 'Unknown site' });
    res.setHeader('Cache-Control', 's-maxage=30, stale-while-revalidate=300');
    return res.status(200).json({ name: site.name, pricing: site.pricing || {} });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Could not load site' });
  }
}
