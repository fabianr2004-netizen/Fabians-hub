// Shared helpers for the hub's server functions. No packages needed.

export const env = (k) => (process.env[k] || '').trim();

export function cors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.status(204).end(); return true; }
  return false;
}

// Talk to Supabase with the server key (never sent to browsers)
export async function db(path, { method = 'GET', body, prefer } = {}) {
  const url = env('SUPABASE_URL'), key = env('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) throw new Error('Supabase keys are not set in Vercel');
  const r = await fetch(`${url}/rest/v1/${path}`, {
    method,
    headers: {
      apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json',
      ...(prefer ? { Prefer: prefer } : {})
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`Supabase ${r.status}: ${text}`);
  return text ? JSON.parse(text) : null;
}

export async function getSite(slug) {
  const rows = await db(`sites?slug=eq.${encodeURIComponent(slug)}&select=id,slug,name,pricing,alert_email,alert_phone`);
  return rows && rows[0];
}

// ---- Alerts ----
export async function sendEmail(to, subject, text) {
  const key = env('RESEND_API_KEY');
  if (!key || !to.length) return 'skipped';
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: env('ALERT_FROM') || "Fabian's Hub <onboarding@resend.dev>", to, subject, text })
  });
  return r.ok ? 'sent' : `failed ${r.status}`;
}

export async function sendText(to, body) {
  const sid = env('TWILIO_ACCOUNT_SID'), token = env('TWILIO_AUTH_TOKEN'), from = env('TWILIO_FROM');
  if (!sid || !token || !from || !to.length) return 'skipped';
  const out = [];
  for (const num of to) {
    const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: 'POST',
      headers: {
        Authorization: 'Basic ' + Buffer.from(`${sid}:${token}`).toString('base64'),
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams({ To: num, From: from, Body: body })
    });
    out.push(r.ok ? 'sent' : `failed ${r.status}`);
  }
  return out.join(',');
}

export const list = (...vals) =>
  [...new Set(vals.flatMap((v) => (v || '').split(',')).map((s) => s.trim()).filter(Boolean))];
