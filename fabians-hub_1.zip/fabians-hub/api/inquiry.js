// POST /api/inquiry  — websites send customer inquiries here.
// Body: { site: 'precision', name, phone, email, vehicle, service, type, quote, date, details, options, ... }
import { cors, db, getSite, sendEmail, sendText, list, env } from './_lib.js';

const clip = (v, n = 500) => (v == null ? null : String(v).slice(0, n));

export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  try {
    const b = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    if (b.website) return res.status(200).json({ ok: true }); // hidden spam-trap field was filled
    if (!b.site) return res.status(400).json({ error: 'Missing site' });
    if (!b.name || !(b.phone || b.email)) return res.status(400).json({ error: 'Name and phone or email are required' });

    const site = await getSite(b.site);
    if (!site) return res.status(404).json({ error: 'Unknown site' });

    const known = ['site', 'name', 'phone', 'email', 'vehicle', 'service', 'type', 'quote', 'date', 'website'];
    const extra = {};
    for (const [k, v] of Object.entries(b)) if (!known.includes(k)) extra[k] = v;
    if (typeof extra.details === 'string') { extra.message = extra.details; delete extra.details; }

    const row = {
      site_id: site.id,
      type: b.type === 'instant' ? 'instant' : 'request',
      name: clip(b.name, 120), phone: clip(b.phone, 40), email: clip(b.email, 160),
      vehicle: clip(b.vehicle, 160), service: clip(b.service, 160),
      quote: Number.isFinite(+b.quote) && b.quote !== '' && b.quote != null ? +b.quote : null,
      preferred_date: clip(b.date, 40),
      details: JSON.stringify(extra).length <= 8000 ? extra : { message: clip(extra.message, 4000) }
    };
    const [saved] = await db('inquiries', { method: 'POST', body: row, prefer: 'return=representation' });

    // Alerts
    const hub = env('HUB_URL');
    const lines = [
      `New ${row.type === 'instant' ? 'instant quote' : 'request'} on ${site.name}`,
      `${row.name} · ${row.phone || ''} ${row.email || ''}`.trim(),
      row.vehicle && `Vehicle: ${row.vehicle}`,
      row.service && `Service: ${row.service}`,
      row.quote != null && `Quote: $${Math.round(row.quote)}`,
      row.preferred_date && `Preferred date: ${row.preferred_date}`,
      extra.message && `Message: ${extra.message}`,
      Array.isArray(extra.options) && extra.options.length && `Options: ${extra.options.join(', ')}`,
      hub && `Open: ${hub}/#/inquiry/${saved.id}`
    ].filter(Boolean);
    const text = lines.join('\n');
    const [email, sms] = await Promise.all([
      sendEmail(list(env('OWNER_EMAIL'), site.alert_email), `New inquiry: ${row.name} (${site.name})`, text),
      sendText(list(env('OWNER_PHONE'), site.alert_phone), lines.slice(0, 5).join('\n') + (hub ? `\n${hub}/#/inquiry/${saved.id}` : ''))
    ]);

    return res.status(200).json({ ok: true, id: saved.id, alerts: { email, sms } });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Could not save inquiry' });
  }
}
