# Fabian's Hub: setup

About 30 minutes on a computer. Do the steps in order. Keep a notes app open to paste keys into as you go.

## 1. GitHub (where the code lives)
1. Go to github.com/signup and create your account.
2. Click **+** (top right) → **New repository**. Name it `fabians-hub`, set it to **Private**, and click **Create repository**.
3. On the next page, click **uploading an existing file**. Unzip `fabians-hub.zip` and drag **everything inside the folder** (index.html, package.json, SETUP.md, and the `api` and `supabase` folders) onto the page. Click **Commit changes**.

## 2. Supabase (database and logins)
1. Go to supabase.com and click **Start your project**. Choose **Continue with GitHub**, so you don't need another password.
2. Click **New project**. Name it `fabians-hub`, make up a database password (save it), choose the region closest to you (**East US**, or **Central US** if offered), and create it. Wait about 2 minutes.
3. In the left menu, open **SQL Editor** → **New query**. Open `supabase/schema.sql`, copy all of it, paste it in, and press **Run**. It should say "Success".
4. Go to **Project Settings** → **API Keys** → the **Legacy API keys** tab. Copy these three into your notes:
   - **Project URL** (on Project Settings → Data API, looks like `https://abcd.supabase.co`)
   - **anon public** key
   - **service_role** key. This one is secret: never paste it into a website.
5. Optional, to log in right away without a confirmation email: **Authentication** → **Sign In / Providers** → **Email** → turn off **Confirm email**.

## 3. Resend (email alerts, free)
1. Go to resend.com and sign up with the email you want alerts sent to.
2. Go to **API Keys** → **Create API key**. Copy it.
   (Until you connect your own domain, Resend only sends to your own signup email. That's fine for alerts to you.)

## 4. Twilio (text alerts, about a penny a text)
1. Go to twilio.com and sign up. Verify your cell number.
2. Get a phone number (**Phone Numbers** → **Buy a number**). On the console home page, copy your **Account SID** and **Auth Token**.
3. Heads-up: US carriers require texting registration (**Messaging** → **Regulatory Compliance**, "A2P 10DLC", or use a toll-free number and verify it). Approval can take a few days. Email alerts work in the meantime.

## 5. Vercel (puts it online, free)
1. Go to vercel.com/signup and choose **Continue with GitHub**.
2. Click **Add New…** → **Project** → **Import** your `fabians-hub` repo.
3. Open **Environment Variables** and add each of these (name on the left, value on the right):

| Name | Value |
|---|---|
| SUPABASE_URL | your Project URL |
| SUPABASE_ANON_KEY | anon public key |
| SUPABASE_SERVICE_ROLE_KEY | service_role key |
| OWNER_EMAIL | the email you get alerts at |
| RESEND_API_KEY | Resend key |
| OWNER_PHONE | your cell, like +15551234567 |
| TWILIO_ACCOUNT_SID | from Twilio |
| TWILIO_AUTH_TOKEN | from Twilio |
| TWILIO_FROM | your Twilio number, like +15557654321 |
| HUB_URL | leave empty for now |

4. Click **Deploy**. When it finishes, copy your address (like `fabians-hub.vercel.app`).
5. Go to **Settings** → **Environment Variables** and set **HUB_URL** to `https://` plus that address. Then go to **Deployments** → **⋯** → **Redeploy**.

## 6. First login
Open your hub address and click **First time? Create account**. The first account becomes the owner (you). Nobody after that can become owner.

## 7. Connect the Precision site
Send Claude your hub address. It'll switch the Precision website's quote form and prices over to the hub.

---
**What's where:** `index.html` is the hub screens. `api/inquiry.js` receives inquiries and sends alerts. `api/site.js` gives websites their live prices. `supabase/schema.sql` is the database.
